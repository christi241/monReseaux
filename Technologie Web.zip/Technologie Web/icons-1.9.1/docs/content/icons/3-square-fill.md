---
title: 3 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
